
import Auth from "./auth.js";

const authObj = new Auth();
document.getElementById("subButton").addEventListener('click', authObj.login);
